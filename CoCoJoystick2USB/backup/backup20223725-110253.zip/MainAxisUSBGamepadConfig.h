#ifndef MainAxisUSBGamepadConfig_h
#define MainAxisUSBGamepadConfig_h

#include "CoCoUSBGamepadConfig.h"

#include <HID-Project.h>
#include <HID-Settings.h>

class MainAxisUSBGamepadConfig : public CoCoGamepadConfig {
  public:

  MainAxisUSBGamepadConfig() {};
  
  void setOutput(int buttonRed, int buttonBlack ) {
    _buttonRed = buttonRed;
    _buttonBlack = buttonBlack;
  }
  
  void btnRedPress() { _gamepad->.press(_buttonRed); }
  void btnRedRelease() { _gamepad->.release(_buttonRed); }
  void btnBlackPress()  { _gamepad->.press(_buttonBlack); }
  void btnBlackRelease() { _gamepad->.release(_buttonBlack); }
  void axisXchange(int value) { _gamepad->.xAxis(value); };
  void axisYchange(int value) { _gamepad->.yAxis(value); };

  void setGamepad(Gamepad *gamepad) { _gamepad = gamepad; }

  void commit() { _gamepad->write(); }
}


#endif
