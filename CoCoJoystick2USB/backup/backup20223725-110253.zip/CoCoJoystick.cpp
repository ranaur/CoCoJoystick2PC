#include "Arduino.h"
#include "CoCoJoystick.h"

#include "SerialPrintGamepadConfig.h"

#include <EEPROM.h>

unsigned long eeprom_crc(int start, int length) {
  const unsigned long crc_table[16] = {
    0x00000000, 0x1db71064, 0x3b6e20c8, 0x26d930ac,
    0x76dc4190, 0x6b6b51f4, 0x4db26158, 0x5005713c,
    0xedb88320, 0xf00f9344, 0xd6d6a3e8, 0xcb61b38c,
    0x9b64c2b0, 0x86d3d2d4, 0xa00ae278, 0xbdbdf21c
  };

  unsigned long crc = ~0L;
  for (int index = start ; index < start + length; ++index) {
    crc = crc_table[(crc ^ EEPROM[index]) & 0x0f] ^ (crc >> 4);
    crc = crc_table[(crc ^ (EEPROM[index] >> 4)) & 0x0f] ^ (crc >> 4);
    crc = ~crc;
  }
  return crc;
}

CoCoJoystick::CoCoJoystick() {
	_pinAxisX = -1;
	_pinAxisY = -1;
	_pinButtonRed = -1;
	_pinButtonBlack = -1;
	_EEPROMOffset = -1;

  setConfig(new SerialPrintGamepadConfig());
}

bool CoCoJoystick::checkEEPROM() {
  if(_EEPROMOffset == -1) { return false; };

  unsigned long calculatedCRC = calculateEEPROMCRC();

  unsigned long savedCRC;
  EEPROM.get(EEPROMCRCOffset(), savedCRC);
  
  return savedCRC == calculatedCRC;
}

int CoCoJoystick::EEPROMCRCOffset() {
  return _EEPROMOffset + EEPROMfootprint - sizeof(unsigned long);
}

unsigned long CoCoJoystick::calculateEEPROMCRC() {
  if(_EEPROMOffset == -1) { return false; };
  return eeprom_crc(_EEPROMOffset, EEPROMfootprint - sizeof(unsigned long));
}

void CoCoJoystick::loadCalibration() {
	if(_EEPROMOffset == -1) { return; };

	if(checkEEPROM()) {
    _axisX.loadCalibration();
    _axisY.loadCalibration();
	} else {
    _axisX.setDefaultCalibration();
    _axisY.setDefaultCalibration();
    saveCalibration();
	}
}

void CoCoJoystick::saveCalibration() {
	if(_EEPROMOffset == -1) { return; };

	_axisX.saveCalibration();
	_axisY.saveCalibration();
  
  EEPROM.update(EEPROMCRCOffset(), calculateEEPROMCRC());
}

void CoCoJoystick::setup(int pinAxisX, int pinAxisY, int pinButtonRed, int pinButtonBlack, int EEPROMOffset = -1)
{
	_pinAxisX = pinAxisX;
	_pinAxisY = pinAxisY;
	_pinButtonRed = pinButtonRed;
	_pinButtonBlack = pinButtonBlack;

	_EEPROMOffset = EEPROMOffset;

  _axisX.setup(pinAxisX, EEPROMOffset, 16);
  _axisY.setup(pinAxisY, EEPROMOffset + Calibration::EEPROMfootprint, 16);
  
  loadCalibration();
  
	_buttonRed.setup(pinButtonRed);
	_buttonBlack.setup(pinButtonBlack);
}

void pressRed(uint32_t forMs, void *obj) {
  ((CoCoGamepadConfig *)obj)->btnRedPress();
}

void pressBlack(uint32_t forMs, void *obj) {
  ((CoCoGamepadConfig *)obj)->btnBlackPress();
}

void releaseRed(uint32_t forMs, void *obj) {
  ((CoCoGamepadConfig *)obj)->btnRedRelease();
}

void releaseBlack(uint32_t forMs, void *obj) {
  ((CoCoGamepadConfig *)obj)->btnBlackRelease();
}

void changeX(int value, void *obj) {
  ((CoCoGamepadConfig *)obj)->axisXchange(value);
}

void changeY(int value, void *obj) {
  ((CoCoGamepadConfig *)obj)->axisYchange(value);
}

void CoCoJoystick::loop() {
	uint32_t now = millis();
	_buttonRed.loop(now);
	_buttonRed.onPressed(::pressRed, _config);
	_buttonRed.onReleased(::releaseRed, _config);

	_buttonBlack.loop(now);
  _buttonBlack.onPressed(::pressBlack, _config);
	_buttonBlack.onReleased(::releaseBlack, _config);

  _axisX.onChanged(::changeX, _config, now);
  _axisY.onChanged(::changeY, _config, now);

  _config->commit();
  // implementar inversão de joysticks/modo _calibrateButton.onRelease(..., 0);
  // implementar calibragem _calibrateButton.onRelease(..., 3000);

}
