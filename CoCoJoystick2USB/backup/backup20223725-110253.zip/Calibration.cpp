#include "Calibration.h"

#include <EEPROM.h>

Calibration::Calibration() {
	setOutput(DEFAULT_MINIMUM, DEFAULT_CENTER, DEFAULT_MAXIMUM);
	setEEPROMOffset(-1);
}

void Calibration::setOutput(int minimum, int center, int maximum) {
	_output.minimum = minimum;
	_output.maximum = maximum;
	_outputCenter = center;
}

void Calibration::setEEPROMOffset(int EEPROMoffset) {
	_EEPROMOffset = EEPROMoffset;
}

void Calibration::loadEEPROM() {
	if(_EEPROMOffset == -1) { return; };

	int offset = _EEPROMOffset;

	EEPROM.get(_EEPROMOffset, _edge.minimum); offset += sizeof(_edge.minimum);
	EEPROM.get(_EEPROMOffset, _edge.maximum); offset += sizeof(_edge.maximum);
	EEPROM.get(_EEPROMOffset, _center.minimum); offset += sizeof(_center.minimum);
	EEPROM.get(_EEPROMOffset, _center.maximum); offset += sizeof(_center.maximum);
}

void Calibration::saveEEPROM() {
	if(_EEPROMOffset == -1) { return; };
	int offset = _EEPROMOffset;

	EEPROM.update(_EEPROMOffset, _edge.minimum); offset += sizeof(_edge.minimum);
	EEPROM.update(_EEPROMOffset, _edge.maximum); offset += sizeof(_edge.maximum);
	EEPROM.update(_EEPROMOffset, _center.minimum); offset += sizeof(_center.minimum);
	EEPROM.update(_EEPROMOffset, _center.maximum); offset += sizeof(_center.maximum);
}

void Calibration::setEdge(int minimum, int maximum) {
	_edge.minimum = minimum;
	_edge.maximum = maximum;
}

void Calibration::setCenter(int minimum, int maximum) {
	_center.minimum = minimum;
	_center.maximum = maximum;
	_centerPoint = (maximum - minimum) / 2;
}

char *Calibration::toString() {
	char buffer[29 + 4 * 6];

	sprintf(buffer, "edge = [ %d, %d ] center = [ %d, %d ]", _edge.minimum, _edge.maximum, _center.minimum, _center.maximum);

	return buffer;
}

int Calibration::map(int real) {
	// return map(rawValueX, 0, 1023, _output.minimum, _output.maximum);
	if(real >= _center.minimum && real <= _center.maximum) return _outputCenter;
	if(real < _center.minimum) return ::map(real, _edge.minimum, _centerPoint, _output.minimum, _outputCenter);
	/* else */
	return ::map(real, _centerPoint, _edge.maximum, _outputCenter, _output.maximum);
}
