#include "AxisEvent.h"

AxisEvent::AxisEvent() {
  _pin = -1;
}

void AxisEvent::setup(int pin, int EEPROMOffset, int tolerance = 0) {
  _pin = pin;
  _tolerance = tolerance;
  calibration.setEEPROMOffset(EEPROMOffset);
  calibration.loadEEPROM();
  //calibration.setOutput(DEFAULT_MINIMUM, DEFAULT_CENTER, DEFAULT_MAXIMUM);

  pinMode(pin, INPUT);
}

void AxisEvent::onChanged(void(*callback)(int, void *), void *obj = (void *)0, uint32_t now = millis()) {
  if(_pin == -1) return; // must use setup() first

  int value = analogRead(_pin);
  if(_lastValue - value > _tolerance || value - _lastValue > _tolerance) {
    _lastValue = value;
    callback(calibration.map(value), obj); 
  }
}

void AxisEvent::setDefaultCalibration() {
    calibration.setEdge(defaultMinimum, defaultMaximum);
    calibration.setCenter(defaultCenterMinium , defaultCenterMaximum);
}

void AxisEvent::loadCalibration() {
    calibration.loadEEPROM();
}

void AxisEvent::saveCalibration() {
    calibration.saveEEPROM();
}
